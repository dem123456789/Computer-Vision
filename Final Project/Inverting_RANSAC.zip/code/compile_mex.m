%% 1] compile regular mex-files
mex -outdir ./mex ./mex/ApplyHomographiesOnLocations_mex.cpp 
mex -outdir ./mex ./mex/ApplyHomographiesOnLocationsFull_mex.cpp
